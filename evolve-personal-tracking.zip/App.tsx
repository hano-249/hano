
import React, { useState, useEffect, useCallback } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Dumbbell, 
  Droplets, 
  Moon, 
  Sun,
  Sparkles, 
  Wind, 
  Coffee,
  Calendar,
  Flame,
  ArrowLeft,
  Plus,
  Minus,
  BookOpen,
  Trophy,
  History,
  Info,
  Play
} from 'lucide-react';
import { INITIAL_TASKS } from './constants';
import { Task, UserStats, Category, DailyLog } from './types';
import { getDailyInspiration } from './services/geminiService';

type View = 'routine' | 'growth' | 'log' | 'history';

const App: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [history, setHistory] = useState<DailyLog[]>([]);
  const [currentView, setCurrentView] = useState<View>('routine');
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('theme');
    return saved === null ? true : saved === 'dark';
  });
  const [isDayStarted, setIsDayStarted] = useState(() => {
    return localStorage.getItem('day_started') === new Date().toDateString();
  });
  const [stats, setStats] = useState<UserStats>({
    streak: 0,
    isWorkoutDay: true,
    lastCompletedDate: '',
    hydrationLevel: 0,
    totalProtein: 0,
    journalEntry: ''
  });
  const [inspiration, setInspiration] = useState<string>("كل تدريب هو استثمار في مستقبلك.");
  const [isLoading, setIsLoading] = useState(true);
  const [showCelebration, setShowCelebration] = useState(false);

  // Dark Mode Sync
  useEffect(() => {
    const root = window.document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  const fetchInspiration = useCallback(async (isWorkout: boolean) => {
    const tip = await getDailyInspiration(isWorkout ? 'بناء العضلات' : 'الاستشفاء');
    if (tip) setInspiration(tip);
  }, []);

  useEffect(() => {
    const savedTasks = localStorage.getItem('evolve_tasks');
    const savedStats = localStorage.getItem('evolve_stats');
    const savedHistory = localStorage.getItem('evolve_history');
    const today = new Date().toDateString();

    const loadedHistory = savedHistory ? JSON.parse(savedHistory) : [];
    setHistory(loadedHistory);

    if (savedTasks && savedStats) {
      const parsedStats = JSON.parse(savedStats);
      if (parsedStats.lastCompletedDate === today) {
        setTasks(JSON.parse(savedTasks));
        setStats(parsedStats);
      } else {
        const prevDayLog: DailyLog = {
          date: parsedStats.lastCompletedDate,
          tasks: JSON.parse(savedTasks),
          stats: parsedStats
        };
        const newHistory = [prevDayLog, ...loadedHistory].slice(0, 30);
        setHistory(newHistory);
        localStorage.setItem('evolve_history', JSON.stringify(newHistory));

        setTasks(INITIAL_TASKS.map(t => ({ ...t, completed: false })));
        setStats(prev => ({
          ...prev,
          lastCompletedDate: today,
          hydrationLevel: 0,
          totalProtein: 0,
          journalEntry: '',
          streak: prev.streak
        }));
        setIsDayStarted(false);
      }
    } else {
      setTasks(INITIAL_TASKS);
      setStats({
        streak: 0,
        isWorkoutDay: true,
        lastCompletedDate: today,
        hydrationLevel: 0,
        totalProtein: 0,
        journalEntry: ''
      });
    }
    
    fetchInspiration(stats.isWorkoutDay);
    setIsLoading(false);
  }, [fetchInspiration]);

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('evolve_tasks', JSON.stringify(tasks));
      localStorage.setItem('evolve_stats', JSON.stringify(stats));
    }
  }, [tasks, stats, isLoading]);

  const startDay = () => {
    setIsDayStarted(true);
    localStorage.setItem('day_started', new Date().toDateString());
  };

  const toggleTask = (id: string) => {
    setTasks(prev => {
      const newTasks = prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
      const activeTasks = newTasks.filter(t => !t.isRestDaySensitive || stats.isWorkoutDay);
      if (activeTasks.every(t => t.completed) && activeTasks.length > 0) {
        setShowCelebration(true);
        setTimeout(() => setShowCelebration(false), 3000);
      }
      return newTasks;
    });
  };

  const toggleWorkoutDay = () => {
    const newValue = !stats.isWorkoutDay;
    setStats(prev => ({ ...prev, isWorkoutDay: newValue }));
    fetchInspiration(newValue);
  };

  const adjustHydration = (amount: number) => {
    setStats(prev => ({
      ...prev,
      hydrationLevel: Math.max(0, Math.min(10, prev.hydrationLevel + amount))
    }));
  };

  const renderTask = (task: Task) => (
    <div key={task.id} className="space-y-3 border-b border-zinc-100 dark:border-white/[0.03] last:border-0 pb-4 last:pb-0">
      <button
        onClick={() => toggleTask(task.id)}
        className="flex items-center w-full group text-right transition-all py-1"
      >
        <div className={`ml-4 transition-all duration-300 ${task.completed ? 'text-emerald-500 scale-110' : 'text-zinc-300 dark:text-zinc-700'}`}>
          {task.completed ? <CheckCircle2 size={24} /> : <Circle size={24} />}
        </div>
        <div className="flex flex-col flex-1">
          <span className={`text-[15px] font-medium transition-all ${task.completed ? 'text-zinc-400 dark:text-zinc-600 line-through' : 'text-zinc-800 dark:text-zinc-200'}`}>
            {task.name}
          </span>
          {task.category === 'Muscle' && !task.completed && (
            <span className="text-[10px] text-emerald-500 flex items-center mt-1 font-bold opacity-80 uppercase tracking-tighter">
              <Info size={10} className="ml-1" />
              تمرين بناء القوة
            </span>
          )}
        </div>
      </button>
    </div>
  );

  const renderCategory = (category: Category, icon: React.ReactNode, title: string) => {
    const categoryTasks = tasks.filter(t => {
      if (category === 'Muscle') {
        return t.category === category && (stats.isWorkoutDay || !t.isRestDaySensitive);
      }
      return t.category === category;
    });

    if (category === 'Muscle' && !stats.isWorkoutDay) return null;

    return (
      <div className="bg-white dark:bg-[#18181b] rounded-[2.2rem] p-6 shadow-xl shadow-black/[0.02] dark:shadow-none border border-zinc-100 dark:border-white/[0.05] mb-5">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="p-2.5 bg-emerald-50 dark:bg-emerald-500/10 rounded-2xl text-emerald-600 dark:text-emerald-400">
              {icon}
            </div>
            <h3 className="text-lg font-bold tracking-tight">{title}</h3>
          </div>
          <span className="text-[10px] font-black text-zinc-300 dark:text-zinc-700 uppercase tracking-widest bg-zinc-50 dark:bg-black/20 px-2 py-0.5 rounded-md">
            {categoryTasks.filter(t => t.completed).length} / {categoryTasks.length}
          </span>
        </div>
        <div className="space-y-4">
          {categoryTasks.map(renderTask)}
        </div>
      </div>
    );
  };

  const renderHistoryView = () => (
    <div className="space-y-5 animate-in fade-in slide-in-from-bottom-6 duration-700">
      <div className="flex items-center space-x-3 space-x-reverse mb-2 px-2">
        <div className="p-3 bg-zinc-100 dark:bg-white/[0.05] rounded-[1.2rem] text-zinc-500 dark:text-zinc-400">
          <History size={24} />
        </div>
        <h2 className="text-2xl font-black tracking-tight">أرشيف الإنجازات</h2>
      </div>

      {history.length === 0 ? (
        <div className="text-center py-24 bg-white dark:bg-[#18181b] rounded-[2.5rem] border border-dashed border-zinc-200 dark:border-white/10">
          <div className="bg-zinc-50 dark:bg-white/5 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Calendar size={40} className="text-zinc-300 dark:text-zinc-800" />
          </div>
          <p className="text-zinc-400 dark:text-zinc-600 font-medium">ابدأ رحلة التغيير اليوم ليظهر تاريخك هنا.</p>
        </div>
      ) : (
        history.map((log, idx) => (
          <div key={idx} className="bg-white dark:bg-[#18181b] rounded-[2rem] p-6 shadow-sm border border-zinc-100 dark:border-white/5">
            <div className="flex justify-between items-center mb-5">
              <div>
                <h4 className="font-black text-lg text-zinc-800 dark:text-zinc-100">{new Date(log.date).toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'short' })}</h4>
                <div className="flex items-center mt-2 space-x-3 space-x-reverse">
                  <span className={`text-[10px] px-2.5 py-1 rounded-full font-black uppercase tracking-wider ${log.stats.isWorkoutDay ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10' : 'bg-blue-50 text-blue-600 dark:bg-blue-500/10'}`}>
                    {log.stats.isWorkoutDay ? 'يوم تمرين' : 'يوم راحة'}
                  </span>
                  <span className="text-[10px] text-zinc-400 font-bold">سلسلة: {log.stats.streak}</span>
                </div>
              </div>
              <div className="text-emerald-500">
                <CheckCircle2 size={28} />
              </div>
            </div>
            
            <div className="flex flex-wrap gap-2">
              {log.tasks.filter(t => t.completed && t.category === 'Muscle').map(t => (
                <span key={t.id} className="bg-zinc-50 dark:bg-black/30 text-zinc-500 dark:text-zinc-400 text-[11px] px-3 py-1.5 rounded-xl font-bold">
                  {t.name.split('(')[0]}
                </span>
              ))}
            </div>

            {log.stats.journalEntry && (
              <div className="mt-5 pt-5 border-t border-zinc-50 dark:border-white/5">
                <p className="text-[13px] text-zinc-500 dark:text-zinc-500 italic leading-relaxed font-light">"{log.stats.journalEntry}"</p>
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );

  if (isLoading) return null;

  return (
    <div className="min-h-screen pb-44 max-w-lg mx-auto px-6 md:px-0 transition-all duration-700 bg-[#f9fafb] dark:bg-[#09090b] text-zinc-900 dark:text-zinc-100 selection:bg-emerald-500/30">
      
      {/* Start Day Overlay */}
      {!isDayStarted && currentView === 'routine' && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-white/90 dark:bg-black/95 backdrop-blur-2xl animate-in fade-in duration-1000">
          <div className="text-center space-y-10 max-w-xs">
            <div className="w-28 h-28 bg-emerald-500 rounded-[2.5rem] mx-auto flex items-center justify-center shadow-[0_20px_50px_rgba(16,185,129,0.3)] animate-pulse rotate-3">
              <Play size={48} className="text-white fill-white ml-2" />
            </div>
            <div className="space-y-3">
              <h2 className="text-4xl font-black tracking-tighter">حان الوقت.</h2>
              <p className="text-zinc-500 dark:text-zinc-400 font-medium leading-relaxed">العالم ينتظر نسختك الأفضل اليوم. ابدأ بكل قوة.</p>
            </div>
            <button 
              onClick={startDay}
              className="w-full py-5 bg-zinc-900 dark:bg-emerald-500 text-white rounded-[2rem] font-black shadow-2xl active:scale-95 transition-all"
            >
              انطلق الآن
            </button>
          </div>
        </div>
      )}

      {showCelebration && (
        <div className="fixed inset-0 pointer-events-none flex items-center justify-center z-[110] animate-in zoom-in duration-500">
          <div className="bg-white dark:bg-zinc-900 p-12 rounded-full shadow-[0_0_100px_rgba(16,185,129,0.4)] border-4 border-emerald-500 scale-125">
            <Trophy size={64} className="text-emerald-500 animate-bounce" />
          </div>
        </div>
      )}

      <header className="pt-14 pb-8">
        <div className="flex justify-between items-start mb-10">
          <div className="animate-in slide-in-from-right-10 duration-700">
            <h1 className="text-5xl font-black tracking-tighter text-zinc-900 dark:text-white">إيفولف<span className="text-emerald-500">.</span></h1>
            <p className="text-zinc-400 dark:text-zinc-500 text-[11px] mt-3 font-black uppercase tracking-[0.3em]">
              {new Date().toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long' })}
            </p>
          </div>
          <div className="flex flex-col items-end space-y-5 animate-in slide-in-from-left-10 duration-700">
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-3.5 bg-white dark:bg-[#18181b] rounded-2xl shadow-xl shadow-black/[0.05] dark:shadow-none border border-zinc-100 dark:border-white/5 active:rotate-12 transition-transform"
            >
              {isDarkMode ? <Sun size={22} className="text-emerald-400" /> : <Moon size={22} className="text-zinc-400" />}
            </button>
             <div className="bg-white dark:bg-[#18181b] rounded-full px-5 py-2 shadow-xl shadow-black/[0.03] dark:shadow-none border border-zinc-100 dark:border-white/10 flex items-center space-x-2 space-x-reverse">
                <Flame size={18} className="text-orange-500 fill-orange-500 animate-pulse" />
                <span className="text-sm font-black tracking-tighter">{stats.streak} يوم</span>
             </div>
          </div>
        </div>

        {currentView === 'routine' && (
          <>
            <div className="bg-zinc-900 dark:bg-emerald-500 text-white rounded-[2.5rem] p-9 shadow-2xl shadow-emerald-500/20 mb-10 relative overflow-hidden group">
              <Sparkles className="absolute -top-12 -left-12 opacity-10 rotate-12 group-hover:scale-125 transition-transform duration-1000" size={200} />
              <h2 className="text-[10px] uppercase tracking-[0.4em] font-black opacity-50 mb-4">تركيز اليوم</h2>
              <p className="text-2xl leading-tight font-black italic tracking-tight">"{inspiration}"</p>
            </div>

            <div className="flex bg-zinc-200/50 dark:bg-black p-1.5 mb-10 rounded-3xl">
              <button 
                onClick={toggleWorkoutDay}
                className={`flex-1 py-4 rounded-[1.4rem] text-[13px] font-black tracking-tight transition-all duration-300 ${stats.isWorkoutDay ? 'bg-white dark:bg-zinc-800 shadow-2xl text-zinc-900 dark:text-white scale-[1.03]' : 'text-zinc-400'}`}
              >
                <Dumbbell size={18} className="inline ml-2" />
                يوم تمرين
              </button>
              <button 
                onClick={toggleWorkoutDay}
                className={`flex-1 py-4 rounded-[1.4rem] text-[13px] font-black tracking-tight transition-all duration-300 ${!stats.isWorkoutDay ? 'bg-white dark:bg-zinc-800 shadow-2xl text-zinc-900 dark:text-white scale-[1.03]' : 'text-zinc-400'}`}
              >
                <Coffee size={18} className="inline ml-2" />
                يوم راحة
              </button>
            </div>
          </>
        )}
      </header>

      <main className="animate-in fade-in slide-in-from-bottom-8 duration-700">
        {currentView === 'routine' && (
          <>
            {renderCategory('Muscle', <Dumbbell size={22} />, 'تمارين القوة')}
            {renderCategory('Nutrition', <Flame size={22} />, 'الوقود والبروتين')}
            
            <div className="bg-white dark:bg-[#18181b] rounded-[2.2rem] p-8 shadow-sm mb-5 border border-zinc-100 dark:border-white/5">
               <div className="flex items-center justify-between mb-10">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <div className="p-2.5 bg-blue-50 dark:bg-blue-500/10 rounded-2xl text-blue-500">
                    <Droplets size={24} />
                  </div>
                  <h3 className="text-lg font-black tracking-tight">ترطيب الجسم</h3>
                </div>
                <span className="text-[10px] font-black text-zinc-300 dark:text-zinc-700 bg-zinc-50 dark:bg-black/20 px-2 py-0.5 rounded-md uppercase">{stats.hydrationLevel * 250}ml / 2.5L</span>
              </div>
              <div className="flex items-center justify-between space-x-6 space-x-reverse">
                <button 
                  onClick={() => adjustHydration(-1)}
                  className="p-5 rounded-full bg-zinc-50 dark:bg-white/[0.03] text-zinc-300 hover:text-red-400 active:scale-75 transition-all"
                >
                  <Minus size={24} />
                </button>
                <div className="flex flex-1 justify-center space-x-2 space-x-reverse">
                  {[...Array(10)].map((_, i) => (
                    <div 
                      key={i} 
                      className={`h-12 w-2 rounded-full transition-all duration-700 ${i < stats.hydrationLevel ? 'bg-blue-400 shadow-[0_0_20px_rgba(96,165,250,0.5)]' : 'bg-zinc-100 dark:bg-white/[0.05]'}`} 
                    />
                  ))}
                </div>
                <button 
                   onClick={() => adjustHydration(1)}
                  className="p-5 rounded-full bg-blue-50 dark:bg-blue-500/10 text-blue-500 active:scale-75 hover:shadow-lg transition-all"
                >
                  <Plus size={24} />
                </button>
              </div>
            </div>

            {renderCategory('Skin', <Wind size={22} />, 'العناية بالبشرة')}
            {renderCategory('Hair', <Sparkles size={22} />, 'صحة الشعر')}
            {renderCategory('Sleep', <Moon size={22} />, 'النوم العميق')}
          </>
        )}

        {currentView === 'growth' && (
          <div className="space-y-6">
            <div className="bg-white dark:bg-[#18181b] rounded-[2.5rem] p-12 border border-zinc-100 dark:border-white/5 text-center shadow-xl shadow-black/[0.02]">
              <Trophy size={70} className="mx-auto text-emerald-500 mb-8 drop-shadow-[0_10px_30px_rgba(16,185,129,0.3)]" />
              <h2 className="text-4xl font-black mb-4 tracking-tighter">رحلة الوحش</h2>
              <p className="text-zinc-400 dark:text-zinc-500 text-sm font-medium mb-10 leading-relaxed">كل قطرة عرق تقربك من هدفك المنشود.</p>
              <div className="grid grid-cols-2 gap-6">
                <div className="p-8 bg-[#f9fafb] dark:bg-black/30 rounded-[2rem] border border-zinc-50 dark:border-white/5">
                  <span className="block text-4xl font-black text-emerald-500">{stats.streak}</span>
                  <span className="text-[10px] uppercase font-black text-zinc-400 tracking-widest mt-2 block">سلسلة نجاح</span>
                </div>
                <div className="p-8 bg-[#f9fafb] dark:bg-black/30 rounded-[2rem] border border-zinc-50 dark:border-white/5">
                  <span className="block text-4xl font-black text-blue-500">{stats.hydrationLevel * 10}%</span>
                  <span className="text-[10px] uppercase font-black text-zinc-400 tracking-widest mt-2 block">خلايا رطبة</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {currentView === 'log' && (
          <div className="bg-white dark:bg-[#18181b] rounded-[2.5rem] p-9 border border-zinc-100 dark:border-white/5 shadow-sm">
            <div className="flex items-center space-x-3 space-x-reverse mb-10">
              <BookOpen size={28} className="text-emerald-500" />
              <h3 className="text-2xl font-black tracking-tight">حديث النفس</h3>
            </div>
            <textarea
              value={stats.journalEntry || ''}
              onChange={(e) => setStats(prev => ({...prev, journalEntry: e.target.value}))}
              placeholder="فرغ أفكارك هنا.. كيف كان أداؤك؟"
              className="w-full h-80 p-8 rounded-[2rem] bg-zinc-50 dark:bg-black/40 text-lg border-none focus:ring-4 focus:ring-emerald-500/10 resize-none placeholder:text-zinc-300 dark:placeholder:text-zinc-800 font-medium transition-all"
            />
          </div>
        )}

        {currentView === 'history' && renderHistoryView()}
      </main>

      {/* Navigation */}
      <nav className="fixed bottom-10 left-1/2 -translate-x-1/2 w-[92%] max-w-sm bg-zinc-900 dark:bg-zinc-800 text-white rounded-[2.5rem] py-6 px-10 flex justify-between items-center shadow-2xl z-50 border border-white/10 backdrop-blur-3xl bg-opacity-95 dark:bg-opacity-80">
        <button onClick={() => setCurrentView('routine')} className={`flex flex-col items-center transition-all ${currentView === 'routine' ? 'text-emerald-400 scale-125' : 'opacity-30 hover:opacity-100'}`}>
          <Calendar size={22} />
        </button>
        
        <button onClick={() => setCurrentView('growth')} className={`flex flex-col items-center transition-all ${currentView === 'growth' ? 'text-emerald-400 scale-125' : 'opacity-30 hover:opacity-100'}`}>
          <Flame size={22} />
        </button>
        
        <button 
          onClick={() => { setCurrentView('routine'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
          className="bg-emerald-500 p-5 rounded-full -mt-20 shadow-[0_20px_50px_rgba(16,185,129,0.4)] border-[8px] border-[#f9fafb] dark:border-[#09090b] active:scale-90 transition-all hover:scale-110"
        >
          <ArrowLeft size={28} strokeWidth={3} />
        </button>
        
        <button onClick={() => setCurrentView('log')} className={`flex flex-col items-center transition-all ${currentView === 'log' ? 'text-emerald-400 scale-125' : 'opacity-30 hover:opacity-100'}`}>
          <BookOpen size={22} />
        </button>
        
        <button onClick={() => setCurrentView('history')} className={`flex flex-col items-center transition-all ${currentView === 'history' ? 'text-emerald-400 scale-125' : 'opacity-30 hover:opacity-100'}`}>
          <History size={22} />
        </button>
      </nav>
    </div>
  );
};

export default App;
