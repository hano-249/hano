
export type Category = 'Muscle' | 'Skin' | 'Hair' | 'Sleep' | 'Nutrition';

export interface Task {
  id: string;
  name: string;
  category: Category;
  completed: boolean;
  notes?: string;
  isRestDaySensitive?: boolean;
  imageUrl?: string; // رابط الصورة التوضيحية (GIF)
}

export interface UserStats {
  streak: number;
  isWorkoutDay: boolean;
  lastCompletedDate: string;
  hydrationLevel: number; // 0-8 glasses
  totalProtein: number; // grams
  journalEntry?: string; // New: Daily reflection
}

export interface DailyLog {
  date: string;
  tasks: Task[];
  stats: UserStats;
}
