
import { Task } from './types';

export const INITIAL_TASKS: Task[] = [
  // نمو العضلات
  { 
    id: 'm1', 
    name: 'تمرين الضغط (3 مجموعات)', 
    category: 'Muscle', 
    completed: false, 
    isRestDaySensitive: true
  },
  { 
    id: 'm2', 
    name: 'تمرين العقلة / السحب (3 مجموعات)', 
    category: 'Muscle', 
    completed: false, 
    isRestDaySensitive: true
  },
  { 
    id: 'm3', 
    name: 'تمرين القرفصاء / الطعنات (3 مجموعات)', 
    category: 'Muscle', 
    completed: false, 
    isRestDaySensitive: true
  },
  { 
    id: 'm4', 
    name: 'تمرين البلانك (60 ثانية)', 
    category: 'Muscle', 
    completed: false, 
    isRestDaySensitive: true
  },
  
  // العناية بالبشرة
  { id: 's1', name: 'تنظيف الصباح واقي الشمس', category: 'Skin', completed: false },
  { id: 's2', name: 'تنظيف المساء والترطيب', category: 'Skin', completed: false },
  
  // العناية بالشعر
  { id: 'h1', name: 'تدليك فروة الرأس (5 دقائق)', category: 'Hair', completed: false },
  { id: 'h2', name: 'يوم غسل الشعر (شامبو وبلسم)', category: 'Hair', completed: false },
  
  // النوم والتغذية
  { id: 'n1', name: 'تناول أكثر من 3000 سعرة حرارية', category: 'Nutrition', completed: false },
  { id: 'n2', name: 'هدف البروتين 150 جرام', category: 'Nutrition', completed: false },
  { id: 'sl1', name: 'نوم لمدة 8 ساعات', category: 'Sleep', completed: false },
  { id: 'sl2', name: 'الابتعاد عن الشاشات قبل النوم بـ 30 دقيقة', category: 'Sleep', completed: false },
];

export const COLORS = {
  primary: '#10B981', // Emerald 500
  bgDark: '#09090b', // Deep Black/Zinc
  cardDark: '#18181b', // Zinc 900
  accent: '#34D399' // Emerald 400
};
