
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getDailyInspiration = async (category: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Provide a single, short, practical tip (max 20 words) in Arabic for a tall, skinny male hard-gainer regarding ${category}. Be calm, encouraging, and disciplined.`,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "الاستمرارية هي مفتاح التقدم. واصل العمل.";
  }
};
